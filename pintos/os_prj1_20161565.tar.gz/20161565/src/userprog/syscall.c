#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"

static void syscall_handler (struct intr_frame *);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}



static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  //printf ("system call! : %d \n",*(uint32_t *)(f->esp));
	//hex_dump(f->esp, f->esp, 100, 1);
	uint32_t sys_num = *(uint32_t *)(f->esp);
	/*
	if(!is_user_vaddr(sys_num)){
		custom_exit(-1);
	}*/
	switch(sys_num){
		case SYS_HALT:
			custom_halt();
			break;

		case SYS_EXIT:
			if(!is_user_vaddr(f->esp+4)){
				custom_exit(-1);
			}
			custom_exit(*(uint32_t *)(f->esp + 4));
			break;

		case SYS_EXEC:
			if(!is_user_vaddr(f->esp+4)){
				custom_exit(-1);
			}
			f->eax = custom_exec((const char *)*(uint32_t *)(f->esp+4));
			break;

		case SYS_WAIT:
			if(!is_user_vaddr(f->esp+4)){
				custom_exit(-1);
			}
			f->eax =custom_wait((pid_t)*(uint32_t *)(f->esp+4));
			break;
		case SYS_CREATE:
			break;
		case SYS_REMOVE:
			break;
		case SYS_OPEN:
			break;
		case SYS_FILESIZE:
			break;
		case SYS_READ:
			if(!is_user_vaddr(f->esp+4)||!is_user_vaddr(f->esp+8)||!is_user_vaddr(f->esp+12)){
				custom_exit(-1);
			}
			f->eax = custom_read((int)*(uint32_t *)(f->esp + 4),(void *)*(uint32_t *)(f->esp + 8),(unsigned)*((uint32_t *)(f->esp + 12)));

			break;

		case SYS_WRITE:
			if(!is_user_vaddr(f->esp+4)||!is_user_vaddr(f->esp+8)||!is_user_vaddr(f->esp+12)){
				custom_exit(-1);
			}
			f->eax = custom_write((int)*(uint32_t *)(f->esp + 4),(void *)*(uint32_t *)(f->esp + 8),(unsigned)*((uint32_t *)(f->esp + 12)));
			break;

		case SYS_SEEK:
			break;

		case SYS_TELL:
			break;

		case SYS_CLOSE:
			break;

		case SYS_MMAP:
			break;

		case SYS_MUNMAP:
			break;

		case SYS_CHDIR:
			break;

		case SYS_MKDIR:
			break;

		case SYS_READDIR:
			break;

		case SYS_ISDIR:
			break;

		case SYS_INUMBER:
			break;

		case SYS_FIBONACCI:
			f->eax = custom_fibonacci((int)*(uint32_t *)(f->esp + 4));
			break;
		
		case SYS_MAX_OF_FOUR_INT:
			//hex_dump(f->esp, f->esp, 100, 1);

			f->eax = custom_max_of_four_int((int)*(uint32_t *)(f->esp + 4), (int)*(uint32_t *)(f->esp + 8), (int)*(uint32_t *)(f->esp + 12), (int)*(uint32_t *)(f->esp + 16));
			break;
	}
 // thread_exit ();
}
void custom_halt(void){
	shutdown_power_off();
}
void custom_exit(int status){
	printf("%s: exit(%d)\n", thread_name(), status);
	thread_current()->exit_status = status;
	thread_exit();
}

pid_t custom_exec(const char* command_line){
	return process_execute(command_line);
}

int custom_wait(pid_t pid){
	return process_wait(pid);
}

int custom_write(int fd, const void *buf, unsigned size){
	//use putbuf
	if(fd == 1){
		putbuf(buf, size);
		return size;
	}
	//incorrect file descriptor
	return -1;
}

int custom_read(int fd, void *buf, unsigned size){
	//use input_getc()
	int read_buffer;
	//read_buffer = -1;
	//void* tmp_buf = buf;
	if(fd == 0){
		//void* tmp_buf = buf;
		//*(uint32_t *)tmp_buf = input_getc();
		read_buffer = input_getc();
	}

	return read_buffer;
}

int custom_fibonacci (int n){
	int tmp1, tmp2, result;
	int i;
	tmp1 = 0;
	result = 1;
	//printf("\n\nfibo a = %d\n\n",n);
	if(n <= 2) return 1;
	
	for(i = 0; i < n; i++){
		tmp2 = result;
		result += tmp1;
		tmp1 = tmp2;
	}
	return tmp1;
}

int custom_max_of_four_int (int a, int b, int c, int d){
	int MAX_ = a;
	//printf("\n\na=%d,\nb=%d,\nc=%d,\nd=%d\n\n",a, b, c, d);	
	if(MAX_ < b){
		MAX_ = b;
	}
	if(MAX_ < c){
		MAX_ = c;
	}
	if(MAX_ < d){
		MAX_ = d;
	}
	 
	return MAX_;
}
